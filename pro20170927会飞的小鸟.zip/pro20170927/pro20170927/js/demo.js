﻿/// <reference path="jquery-1.10.2.min.js" />
var rcode = 39;
var step = 10;
$(function () {//页面加载完成之后
    var off = $("#dbird").offset();//方位对象
    var dheight = $(window).height();//获得浏览器的高度
    var dwidth = $(window).width();//获得浏览器的宽度
    var bwidth = $("#dbird").width();//获得小鸟的宽度
    var bheigth = $("#dbird").height();//获得小鸟的高度
    $(document).keydown(function (e) {//键盘事件

        var keyCode = e.keyCode;
        if (keyCode != rcode) {
            $("#dbird").removeClass().addClass("direction-" + keyCode);
        }
        rcode = keyCode;
        switch (keyCode) {
            case 37://左
                off.left -= step;
                if (off.left <= -bwidth) {
                    off.left = dwidth;
                }
                break;
            case 38://上
                off.top -= step;
                if (off.top <= -bheigth) {
                    off.top = dheight;
                }
                break;
            case 39://右
                off.left += step;
                if (off.left >= dwidth) {
                    off.left = -bwidth;
                }
                break;
            case 40://下
                off.top += step;
                if (off.top >= dheight) {
                    off.top = -bheigth;
                }
                break;
       }
        $("#dbird").offset(off);//更新小鸟的位置
    });
});